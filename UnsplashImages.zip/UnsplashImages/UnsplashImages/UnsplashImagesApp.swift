//
//  UnsplashImagesApp.swift
//  UnsplashImages
//
//  Created by Divyanshu rai on 13/09/24.
//

import SwiftUI

@main
struct UnsplashImagesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
